package com.brokerage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrokerageFirmApplication {

	public static void main(String[] args) {
		SpringApplication.run(BrokerageFirmApplication.class, args);
	}
}